package com.train.trainbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.train.trainbooking.entity.Train;
import com.train.trainbooking.repository.TrainRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/trains")
@CrossOrigin("*")
public class TrainController {

    @Autowired
    private TrainRepository trainRepo;

    //  ADD TRAIN 
    @PostMapping
    public Train addTrain(@RequestBody Train train) {
        return trainRepo.save(train);
    }

    //  GET ALL TRAINS 
    @GetMapping
    public List<Train> getAllTrains() {
        return trainRepo.findAll();
    }

    //  GET TRAIN BY ID 
    @GetMapping("/{id}")
    public Optional<Train> getTrainById(@PathVariable Long id) {
        return trainRepo.findById(id);
    }

    //  GET BY TRAIN NUMBER 
    @GetMapping("/number/{trainNumber}")
    public List<Train> getByTrainNumber(@PathVariable String trainNumber) {
        return trainRepo.findByTrainNumber(trainNumber);
    }

    //  GET BY TRAIN NAME 
    @GetMapping("/name/{trainName}")
    public List<Train> getByTrainName(@PathVariable String trainName) {
        return trainRepo.findByTrainName(trainName);
    }

    //  GET BY SOURCE 
    @GetMapping("/source/{source}")
    public List<Train> getBySource(@PathVariable String source) {
        return trainRepo.findBySource(source);
    }

    //  GET BY DESTINATION 
    @GetMapping("/destination/{destination}")
    public List<Train> getByDestination(@PathVariable String destination) {
        return trainRepo.findByDestination(destination);
    }

    //  GET BY TOTAL SEATS 
    @GetMapping("/seats/{totalSeats}")
    public List<Train> getBySeats(@PathVariable int totalSeats) {
        return trainRepo.findByTotalSeats(totalSeats);
    }

    //  GET BY PRICE 
    @GetMapping("/price/{price}")
    public List<Train> getByPrice(@PathVariable double price) {
        return trainRepo.findByPrice(price);
    }

    //  UPDATE TRAIN 
    @PutMapping("/{id}")
    public Train updateTrain(@PathVariable Long id, @RequestBody Train train) {

        Train existingTrain = trainRepo.findById(id).orElseThrow(
                () -> new RuntimeException("Train not found")
        );

        existingTrain.setTrainNumber(train.getTrainNumber());
        existingTrain.setTrainName(train.getTrainName());
        existingTrain.setSource(train.getSource());
        existingTrain.setDestination(train.getDestination());
        existingTrain.setTotalSeats(train.getTotalSeats());
        existingTrain.setPrice(train.getPrice());

        return trainRepo.save(existingTrain);
    }

    //  DELETE TRAIN 
    @DeleteMapping("/{id}")
    public String deleteTrain(@PathVariable Long id) {

        if (!trainRepo.existsById(id)) {
            return "Train not found";
        }

        trainRepo.deleteById(id);
        return "Train deleted successfully";
    }
}
