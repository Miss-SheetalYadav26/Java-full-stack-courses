package com.train.trainbooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.train.trainbooking.entity.Train;

import java.util.List;

public interface TrainRepository extends JpaRepository<Train, Long> {

    // 🔍 Search APIs
    List<Train> findByTrainNumber(String trainNumber);

    List<Train> findByTrainName(String trainName);

    List<Train> findBySource(String source);

    List<Train> findByDestination(String destination);

    List<Train> findByTotalSeats(int totalSeats);

    List<Train> findByPrice(double price);
}
