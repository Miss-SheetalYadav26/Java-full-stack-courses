package com.train.trainbooking.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import com.train.trainbooking.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
}
