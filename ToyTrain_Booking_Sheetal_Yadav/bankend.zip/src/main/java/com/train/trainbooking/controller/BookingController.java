package com.train.trainbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.train.trainbooking.entity.Booking;
import com.train.trainbooking.entity.Train;
import com.train.trainbooking.entity.User;
import com.train.trainbooking.repository.BookingRepository;
import com.train.trainbooking.repository.TrainRepository;
import com.train.trainbooking.repository.UserRepository;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin("*")
public class BookingController {

    @Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private TrainRepository trainRepo;

    @Autowired
    private UserRepository userRepo;

    //BOOK TICKET 
    @PostMapping
    public Booking bookTicket(@RequestParam Long userId,
                              @RequestParam Long trainId,
                              @RequestParam int seats) {

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Train train = trainRepo.findById(trainId)
                .orElseThrow(() -> new RuntimeException("Train not found"));

        if (train.getTotalSeats() < seats) {
            throw new RuntimeException("Not enough seats available");
        }

        // 🔽 Reduce seats
        train.setTotalSeats(train.getTotalSeats() - seats);
        trainRepo.save(train);

        // 📌 Create booking
        Booking booking = new Booking();
        booking.setUser(user);
        booking.setTrain(train);
        booking.setSeatsBooked(seats);
        booking.setBookingDate(LocalDate.now());
        booking.setStatus("CONFIRMED"); // dummy payment success

        return bookingRepo.save(booking);
    }

    //GET BOOKINGS BY USER 
    @GetMapping("/user/{userId}")
    public List<Booking> getBookingsByUser(@PathVariable Long userId) {
        return bookingRepo.findByUserId(userId);
    }

    //  GET ALL BOOKINGS (ADMIN) 
    @GetMapping
    public List<Booking> getAllBookings() {
        return bookingRepo.findAll();
    }
}
