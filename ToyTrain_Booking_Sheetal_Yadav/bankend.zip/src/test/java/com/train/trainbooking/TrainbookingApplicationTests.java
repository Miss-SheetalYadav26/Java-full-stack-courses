package com.train.trainbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainbookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
