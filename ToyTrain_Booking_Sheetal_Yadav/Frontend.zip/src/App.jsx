import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import UserDashboard from "./pages/UserDashboard";
import TrainList from "./pages/TrainList";
import BookTicket from "./pages/BookTicket";
import MyBookings from "./pages/MyBookings";
import AdminDashboard from "./pages/AdminDashboard";

function AppLayout() {
  const location = useLocation();

  const isHomePage = location.pathname === "/";

  return (
    <>
      {/* HEADER SIRF HOME PAGE PAR */}
      {isHomePage && <Header />}

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/user" element={<UserDashboard />} />
        <Route path="/trains" element={<TrainList />} />
        <Route path="/book/:trainId" element={<BookTicket />} />
        <Route path="/my-bookings" element={<MyBookings />} />
        <Route path="/admin" element={<AdminDashboard />} />
      </Routes>

      {/* footer already correct */}
      {isHomePage && <Footer />}
    </>
  );
}


export default function App() {
  return (
    <BrowserRouter>
      <AppLayout />
    </BrowserRouter>
  );
}
