import { useNavigate } from "react-router-dom";

export default function UserDashboard() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const logout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <div
      className="container d-flex justify-content-center align-items-center"
      style={{ minHeight: "75vh" }}
    >
      <div
        className="card shadow-lg border-0 w-100"
        style={{ maxWidth: "700px" }}
      >
        <div className="card-body text-center p-5">
          <h2 className="text-primary mb-2">
            Welcome, {user?.name}
          </h2>

          <p className="text-muted mb-4">
            Manage your bookings and explore available trains
          </p>

          <div className="row g-3 justify-content-center">
            <div className="col-md-4 col-sm-6">
              <button
                onClick={() => navigate("/trains")}
                className="btn btn-primary btn-lg w-100"
              >
                🚆 View Trains
              </button>
            </div>

            <div className="col-md-4 col-sm-6">
              <button
                onClick={() => navigate("/my-bookings")}
                className="btn btn-info btn-lg w-100 text-white"
              >
                📄 My Bookings
              </button>
            </div>

            {/* ✅ NEW BACK TO HOME BUTTON */}
            <div className="col-md-4 col-sm-6">
              <button
                onClick={() => navigate("/")}
                className="btn btn-secondary btn-lg w-100"
              >
                🏠 Back to Home
              </button>
            </div>

            <div className="col-md-4 col-sm-6">
              <button
                onClick={logout}
                className="btn btn-danger btn-lg w-100"
              >
                🚪 Logout
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
