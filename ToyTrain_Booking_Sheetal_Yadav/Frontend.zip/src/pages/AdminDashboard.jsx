import { useEffect, useState } from "react";
import api from "../services/api";
import { useNavigate } from "react-router-dom";

export default function AdminDashboard() {
  const navigate = useNavigate();

  const [trains, setTrains] = useState([]);
  const [editId, setEditId] = useState(null);

  const [form, setForm] = useState({
    trainNumber: "",
    trainName: "",
    source: "",
    destination: "",
    totalSeats: "",
    price: "",
  });

  const loadTrains = () => {
    api.get("/trains")
      .then((res) => setTrains(res.data))
      .catch(() => alert("Error loading trains"));
  };

  useEffect(() => {
    loadTrains();
  }, []);

  const submitTrain = async (e) => {
    e.preventDefault();

    try {
      if (editId) {
        await api.put(`/trains/${editId}`, form);
        alert("Train updated successfully");
      } else {
        await api.post("/trains", form);
        alert("Train added successfully");
      }

      setForm({
        trainNumber: "",
        trainName: "",
        source: "",
        destination: "",
        totalSeats: "",
        price: "",
      });
      setEditId(null);
      loadTrains();
    } catch {
      alert("Operation failed");
    }
  };

  const editTrain = (train) => {
    setEditId(train.id);
    setForm({
      trainNumber: train.trainNumber,
      trainName: train.trainName,
      source: train.source,
      destination: train.destination,
      totalSeats: train.totalSeats,
      price: train.price,
    });
  };

  const deleteTrain = async (id) => {
    if (!window.confirm("Delete this train?")) return;
    await api.delete(`/trains/${id}`);
    loadTrains();
  };

  return (
    <div className="container my-4">
      {/* 🔝 TOP BAR */}
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2 className="text-primary m-0">Admin Dashboard</h2>
        <button
          onClick={() => navigate("/")}
          className="btn btn-outline-secondary"
        >
          🏠 Back to Home
        </button>
      </div>

      {/* ADD / UPDATE CARD */}
      <div className="card shadow-sm mb-4">
        <div className="card-body">
          <h5 className="mb-3">
            {editId ? "Update Train" : "Add New Train"}
          </h5>

          <form onSubmit={submitTrain}>
            <div className="row g-3">
              {Object.keys(form).map((key) => (
                <div className="col-md-6" key={key}>
                  <input
                    className="form-control"
                    placeholder={key}
                    value={form[key]}
                    onChange={(e) =>
                      setForm({ ...form, [key]: e.target.value })
                    }
                    required
                  />
                </div>
              ))}
            </div>

            <div className="mt-4">
              <button type="submit" className="btn btn-primary me-2">
                {editId ? "Update Train" : "Add Train"}
              </button>

              {editId && (
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => {
                    setEditId(null);
                    setForm({
                      trainNumber: "",
                      trainName: "",
                      source: "",
                      destination: "",
                      totalSeats: "",
                      price: "",
                    });
                  }}
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>
      </div>

      {/* TRAIN LIST */}
      <div className="card shadow-sm">
        <div className="card-body">
          <h5 className="mb-3">All Trains</h5>

          <div className="table-responsive">
            <table className="table table-bordered table-hover">
              <thead className="table-light">
                <tr>
                  <th>No</th>
                  <th>Name</th>
                  <th>Route</th>
                  <th>Seats</th>
                  <th>Price</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {trains.map((t) => (
                  <tr key={t.id}>
                    <td>{t.trainNumber}</td>
                    <td>{t.trainName}</td>
                    <td>{t.source} → {t.destination}</td>
                    <td>{t.totalSeats}</td>
                    <td>₹{t.price}</td>
                    <td>
                      <button
                        className="btn btn-sm btn-info me-2 text-white"
                        onClick={() => editTrain(t)}
                      >
                        Edit
                      </button>
                      <button
                        className="btn btn-sm btn-danger"
                        onClick={() => deleteTrain(t.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {trains.length === 0 && (
              <p className="text-center text-muted">No trains available</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
