import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";

export default function Register() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
  });

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    try {
      await api.post("/auth/register", form);
      setSuccess("Registration successful! Redirecting to login...");
      setForm({ name: "", email: "", password: "" });

      setTimeout(() => navigate("/login"), 1500);
    } catch {
      setError("Registration failed. Email may already exist.");
    }
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center"
      style={{
        minHeight: "85vh",
        background:
          "linear-gradient(135deg, #e3f2fd 0%, #f8f9fa 60%)",
      }}
    >
      <div className="card shadow-lg border-0" style={{ width: "420px" }}>
        <div className="card-body p-4">
          <h3 className="text-center text-primary mb-1">
            Create Account
          </h3>
          <p className="text-center text-muted mb-4">
            Register to book train tickets
          </p>

          {error && (
            <div className="alert alert-danger text-center py-2">
              {error}
            </div>
          )}

          {success && (
            <div className="alert alert-success text-center py-2">
              {success}
            </div>
          )}

          <form onSubmit={handleRegister}>
            <div className="mb-3">
              <label className="form-label fw-semibold">
                Full Name
              </label>
              <input
                type="text"
                name="name"
                className="form-control form-control-lg"
                placeholder="Enter your name"
                value={form.name}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label className="form-label fw-semibold">
                Email Address
              </label>
              <input
                type="email"
                name="email"
                className="form-control form-control-lg"
                placeholder="Enter your email"
                value={form.email}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-4">
              <label className="form-label fw-semibold">
                Password
              </label>
              <input
                type="password"
                name="password"
                className="form-control form-control-lg"
                placeholder="Create a password"
                value={form.password}
                onChange={handleChange}
                required
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary btn-lg w-100"
            >
              Register
            </button>
          </form>

          <div className="text-center mt-3">
            <span className="text-muted">
              Already have an account?
            </span>{" "}
            <span
              className="text-primary fw-semibold"
              style={{ cursor: "pointer" }}
              onClick={() => navigate("/login")}
            >
              Login here
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
