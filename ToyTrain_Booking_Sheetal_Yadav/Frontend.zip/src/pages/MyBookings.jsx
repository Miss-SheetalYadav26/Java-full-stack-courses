import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";

export default function MyBookings() {
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user"));
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    api.get(`/bookings/user/${user.id}`)
      .then((res) => setBookings(res.data))
      .catch(() => alert("Error loading bookings"));
  }, [user.id]);

  return (
    <div className="container my-4">
      {/* HEADER ROW */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="text-primary">My Bookings</h2>

        {/* ✅ BACK TO DASHBOARD BUTTON */}
        <button
          onClick={() => navigate("/user")}
          className="btn btn-outline-secondary"
        >
          🏠 Back to Dashboard
        </button>
      </div>

      <div className="card shadow-sm">
        <div className="card-body">
          <div className="table-responsive">
            <table className="table table-bordered table-hover align-middle">
              <thead className="table-light">
                <tr>
                  <th>Train</th>
                  <th>Route</th>
                  <th>Seats</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {bookings.map((b) => (
                  <tr key={b.id}>
                    <td>{b.train.trainName}</td>
                    <td>
                      {b.train.source} → {b.train.destination}
                    </td>
                    <td>{b.seatsBooked}</td>
                    <td>
                      <span className="badge bg-success">
                        {b.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {bookings.length === 0 && (
              <p className="text-center text-muted mt-3">
                No bookings found
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
