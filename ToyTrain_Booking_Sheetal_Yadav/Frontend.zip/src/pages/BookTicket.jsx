import { useParams, useNavigate } from "react-router-dom";
import { useState } from "react";
import api from "../services/api";

export default function BookTicket() {
  const { trainId } = useParams();
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));
  const [seats, setSeats] = useState(1);

  const book = async () => {
    try {
      await api.post(
        `/bookings?userId=${user.id}&trainId=${trainId}&seats=${seats}`
      );
      alert("Booking Confirmed!");
      navigate("/my-bookings");
    } catch {
      alert("Booking failed");
    }
  };

  return (
    <div
      className="container d-flex justify-content-center align-items-center"
      style={{ minHeight: "75vh" }}
    >
      <div className="card shadow-lg border-0" style={{ maxWidth: "450px", width: "100%" }}>
        <div className="card-body p-4">
          <h3 className="text-center text-primary mb-3">
            Book Ticket
          </h3>

          <p className="text-center text-muted mb-4">
            Train ID: <strong>{trainId}</strong>
          </p>

          <div className="mb-4">
            <label className="form-label fw-semibold">
              Number of Seats
            </label>
            <input
              type="number"
              min="1"
              className="form-control form-control-lg"
              value={seats}
              onChange={(e) => setSeats(e.target.value)}
            />
          </div>

          <button
            onClick={book}
            className="btn btn-success btn-lg w-100"
          >
            ✅ Confirm Booking
          </button>

          <button
            onClick={() => navigate("/trains")}
            className="btn btn-outline-secondary w-100 mt-3"
          >
            ⬅ Back to Trains
          </button>
        </div>
      </div>
    </div>
  );
}
