import { useEffect, useState } from "react";
import api from "../services/api";
import { useNavigate } from "react-router-dom";

export default function TrainList() {
  const [trains, setTrains] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    api.get("/trains")
      .then((res) => setTrains(res.data))
      .catch(() => alert("Error loading trains"));
  }, []);

  return (
    <div className="container my-4">
      {/* 🔙 TOP ACTIONS */}
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2 className="text-primary m-0">Available Trains</h2>

        <button
  onClick={() => navigate("/user")}
  className="btn btn-outline-secondary"
>
  🏠 Back to Dashboard
</button>

      </div>

      <div className="card shadow-sm">
        <div className="card-body">
          <div className="table-responsive">
            <table className="table table-bordered table-hover align-middle">
              <thead className="table-light">
                <tr>
                  <th>Train No</th>
                  <th>Name</th>
                  <th>Source</th>
                  <th>Destination</th>
                  <th>Seats</th>
                  <th>Price</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {trains.map((t) => (
                  <tr key={t.id}>
                    <td>{t.trainNumber}</td>
                    <td>{t.trainName}</td>
                    <td>{t.source}</td>
                    <td>{t.destination}</td>
                    <td>{t.totalSeats}</td>
                    <td>₹{t.price}</td>
                    <td>
                      <button
                        className="btn btn-success btn-sm"
                        onClick={() => navigate(`/book/${t.id}`)}
                      >
                        Book
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {trains.length === 0 && (
              <p className="text-center text-muted my-3">
                No trains available
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
