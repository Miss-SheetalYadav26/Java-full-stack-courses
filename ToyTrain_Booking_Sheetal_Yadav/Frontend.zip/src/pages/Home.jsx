import { useEffect, useState } from "react";
import "./Home.css";

import hero1 from "../assets/hero1.jpg";
import hero2 from "../assets/hero2.jpg";
import hero3 from "../assets/hero3.jpg";

const images = [hero1, hero2, hero3];

export default function Home() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % images.length);
    }, 4000);

    return () => clearInterval(timer);
  }, []);

  const next = () => {
    setIndex((index + 1) % images.length);
  };

  const prev = () => {
    setIndex((index - 1 + images.length) % images.length);
  };

  return (
    <div>

      {/* ============ HERO SECTION ============ */}
      <section className="hero-section">
        <img
          src={images[index]}
          alt="Garden Toy Train"
          className="hero-image"
        />

        <div className="hero-text">
          <h1>Welcome to Fun Land</h1>
          <p>🌿 Garden Toy Train Booking System 🚆</p>
        </div>

        <button className="hero-arrow left" onClick={prev}>❮</button>
        <button className="hero-arrow right" onClick={next}>❯</button>
      </section>


      {/* ============ FEATURE SECTION ============ */}
<section className="feature-section">
  <div className="container">
    <h2 className="section-title">🌿 Garden Toy Train Experiences</h2>

    <div className="feature-grid">
      <a
        href="https://www.matheranhillrailway.com"
        target="_blank"
        rel="noreferrer"
        className="feature-card"
      >
        <div className="icon">🚂</div>
        <h3>Toy Train Garden Ride</h3>
        <p>Peaceful green garden railway experience</p>
      </a>

      <a
        href="https://www.sanjaygandhinationalpark.org"
        target="_blank"
        rel="noreferrer"
        className="feature-card"
      >
        <div className="icon">🌳</div>
        <h3>Jungle Garden Train</h3>
        <p>Trees, animals & kids-friendly jungle rides</p>
      </a>

      <a
        href="https://www.nilgirimountainrailway.org"
        target="_blank"
        rel="noreferrer"
        className="feature-card"
      >
        <div className="icon">🏞</div>
        <h3>Mini Scenic Railway</h3>
        <p>Hills, bridges & play-zone routes</p>
      </a>
    </div>
  </div>
</section>



    {/* ============ GARDEN ROUTES SECTION ============ */}
<section className="routes-section">
  <div className="container">
    <h2 className="routes-title">🍃 Popular Garden Train Routes</h2>

    <div className="routes-grid">
      <div className="route-card">
        <span className="route-icon">🌊</span>
        <h4>Lake View Route</h4>
        <p>Peaceful lakeside garden tracks</p>
      </div>

      <div className="route-card">
        <span className="route-icon">🌳</span>
        <h4>Jungle Zone Route</h4>
        <p>Green jungle paths with nature views</p>
      </div>

      <div className="route-card">
        <span className="route-icon">🦖</span>
        <h4>Dinosaur Park</h4>
        <p>Fun rides through dinosaur attractions</p>
      </div>

      

      <div className="route-card">
        <span className="route-icon">🏙</span>
        <h4>Mini City</h4>
        <p>Kids-friendly city-style toy train route</p>
      </div>
      
    </div>
  </div>
</section>


      {/* ============ FAQ SECTION ============ */}
<section id="faq" className="faq-section">
  <div className="container">
    <h2 className="faq-title">❓ Frequently Asked Questions</h2>

    <div className="faq-list">
      <details className="faq-item">
        <summary>How can I book a garden toy train ticket?</summary>
        <p>
          Simply login, explore available garden trains, select your route
          and confirm booking.
        </p>
      </details>

      <details className="faq-item">
        <summary>Is this booking system safe for kids?</summary>
        <p>
          Yes, garden toy trains are designed for children and families,
          ensuring a safe and enjoyable experience.
        </p>
      </details>

      <details className="faq-item">
        <summary>Do I get instant booking confirmation?</summary>
        <p>
          Yes, bookings are confirmed instantly after successful selection.
        </p>
      </details>

      <details className="faq-item">
        <summary>Can I view my booked tickets?</summary>
        <p>
          Yes, all your bookings are available in the “My Bookings” section
          after login.
        </p>
      </details>

      <details className="faq-item">
        <summary>Which technologies are used in this system?</summary>
        <p>
          Frontend is built using ReactJS, and backend uses Spring Boot with
          MySQL database.
        </p>
      </details>
       </div>
      </div>
      </section>

    {/* ============ ABOUT US SECTION ============ */}
<section id="about" className="about-section">
  <div className="container">
    <h2 className="about-title">🌼 About Garden Toy Train Booking System</h2>

    <div className="about-card">
      <p>
        The <strong>Garden Toy Train Booking System</strong> is a family-friendly,
        scenic travel platform designed to make short garden and heritage train
        rides easy to explore and enjoyable to book.
      </p>

      <p>
        This system focuses on joyful experiences like toy trains through gardens,
        jungle zones, lake views, dinosaur parks, heritage villages, and mini cities.
        It is ideal for kids, families, and tourists looking for safe, memorable
        rides in green environments.
      </p>

      <p>
        The application is built as a modern full-stack project using
        <strong> ReactJS</strong> for a smooth user interface,
        <strong> Spring Boot</strong> for secure backend services,
        and <strong> MySQL</strong> for reliable data storage.
      </p>

      <p>
        Key features include browsing routes, booking tickets, managing bookings,
        and a responsive design that works seamlessly across mobile, tablet,
        and desktop devices.
      </p>
    </div>
  </div>
</section>

      {/* ============ CONTACT US SECTION ============ */}
<section id="contact" className="contact-section">
  <div className="container">
    <h2 className="contact-title">📞 Contact Us</h2>

    <div className="contact-grid">
      <div className="contact-card">
        <div className="contact-icon">📧</div>
        <h4>Email</h4>
        <p>support@gardentoytrain.com</p>
      </div>

      <div className="contact-card">
        <div className="contact-icon">📱</div>
        <h4>Phone</h4>
        <p>+91 98765 43210</p>
      </div>

      <div className="contact-card">
        <div className="contact-icon">📍</div>
        <h4>Location</h4>
        <p>Garden Railway Park, India</p>
      </div>
    </div>
  </div>
</section>


    </div>
  );
}
