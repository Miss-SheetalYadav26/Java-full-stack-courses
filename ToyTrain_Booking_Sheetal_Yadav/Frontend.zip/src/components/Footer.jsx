export default function Footer() {
  return (
    <footer className="home-footer">
      <div className="container text-center">
        <p className="footer-title">
          🚆 © 2026 <strong>Train Ticket Booking System</strong>
        </p>

        <p className="footer-sub">
          🎫 Easy Booking &nbsp;•&nbsp; 🚄 Fast Trains &nbsp;•&nbsp; 🧳 Safe Travel
        </p>
      </div>
    </footer>
  );
}
