import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";

export default function Header() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();

    // 🔒 Backend safe:
    // Sirf navigation, koi API call nahi
    if (query.trim() !== "") {
      navigate(`/trains?search=${query}`);
    }
  };

  return (
    
<nav
  className="navbar navbar-expand-lg navbar-dark shadow fixed-top"
  style={{ backgroundColor: "#0c4133" }}   // Garden Green
>
      <div className="container">

        {/* 🔹 Logo / Title */}
        <Link className="navbar-brand fw-bold fs-4" to="/">
          🚆 Train Booking
        </Link>

        {/* 🔹 Toggle (mobile) */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">

          {/* 🔍 Search box (center) */}
          <form
            className="d-flex mx-auto my-2 my-lg-0"
            onSubmit={handleSearch}
            style={{
            maxWidth: "380px",
            width: "100%"
             
        }}
          >
            <input
              className="form-control me-2"
              type="search"
              placeholder="Search train / city"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <button className="btn btn-light" type="submit"style={{ backgroundColor: "#58e15f", color: "#fff" }}>
              🔍
            </button>
          </form>

          {/* 🔹 Right menu */}
          <ul className="navbar-nav ms-auto align-items-center">

            <li className="nav-item">
              <Link className="nav-link" to="/">
                🏠 Home
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/login">
                🔐 Login
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/register">
                📝 Register
              </Link>
            </li>

            
            <li className="nav-item">
              <span
              className="nav-link"
                style={{ cursor: "pointer" }}
                onClick={() => {
                const section = document.getElementById("about");
                if (section) {
               section.scrollIntoView({ behavior: "smooth" });
              }
            }}
            >
              
               <center> ℹ️ </center>
               <center>About Us</center>
            </span>
          </li>




           <li className="nav-item">
            <span
                className="nav-link"
              style={{ cursor: "pointer" }}
              onClick={() => {
              const section = document.getElementById("contact");
              if (section) {
              section.scrollIntoView({ behavior: "smooth" });
             }
           }}
           >
           📞 Contact Us
          </span>
          </li>


            <li className="nav-item">
           <span
              className="nav-link"
              style={{ cursor: "pointer" }}
              onClick={() => {
              const faqSection = document.getElementById("faq");
              if (faqSection) {
              faqSection.scrollIntoView({ behavior: "smooth" });
             }
              }}
              >
              ❓ FAQ
              </span>
            </li>


            {/* 🚉 Train icon */}
            <li className="nav-item fs-4 ms-3">
              🚉
            </li>

          </ul>
        </div>
      </div>
    </nav>
  );
}
